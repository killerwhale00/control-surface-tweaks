-- Control Surface Tweaks
-- Increases the deflection and deploy angle limits on all control surfaces,
-- grid fins, and the airbrake. Also sets default authority limiter per part type.

--  config 
local enabledmod = Config:Bool(
    "Mod Toggle",
    "Enable Mod",
    true,
    "Toggle the entire mod on or off.\n<color=#FF4444>⚠ Restart required to apply changes.</color>"
)
-- added new full toggle so you can keep specific values if you want to 

local deflectionRange = Config:Float(
    "Control Surfaces",
    "Max deflection angle for control surfaces (degrees)",
    25.0,
    1.0,
    180.0,
    "Maximum deflection angle in degrees for flight control. Stock default is ~25°, \n <color=#FF4444>⚠ Restart required to apply changes.</color>" 
)

local ctrlSurfaceAuthorityAngle = Config:Float(
    "Control Surfaces",
    "Default Authority Limiter for control surfaces (degrees)",
    25.0,
    1.0,
    180.0,
    "Sets the default authority limiter for procedural control surfaces in degrees.\nCannot exceed the Max Deflection Angle if it does it will be clamped to 100%.\n <color=#F5D433>⚠ Do not set above 45° unless you want the sas to freak out.</color>\n<color=#FF4444>⚠ Restart required to apply changes.</color>"
)

local deployAngle = Config:Float(
    "Airbrake and Grid fins",
    "Max deploy Angle for gridfins and airbrake  (degrees)",
    90.0,
    1.0,
    180.0,
    "Maximum deflection angle in degrees for Grid fins and Airbrakes. Stock default is 90°.  \n <color=#FF4444>⚠ Restart required to apply changes.</color>"
)

local gridFinAuthorityAngle = Config:Float(
    "Airbrake and Grid fins",
    "Default Authority Limiter for grid fins (degrees)",
    35.0,
    1.0,
    180.0,
    "Sets the default authority limiter for grid fins in degrees.\n Cannot exceed the Max Deploy Angle if it does it will be clamped to 100% \n <color=#F5D433>⚠ Do not set above 45° unless you want the sas to freak out.</color>.\n<color=#FF4444>⚠ Restart required to apply changes.</color>"
)


-- almost did /n 
-- also got color now :)

local function clamp(value, min, max)
    return math.max(min, math.min(max, value))
end

local function patchSurface(part, authorityAngle, rangeAngle)
    part:PatchModule("Module_ControlSurface", function(module)
        module:PatchData("Data_ControlSurface", function(data)
            data.CtrlSurfaceRange       = rangeAngle
            data.CtrlSurfaceDeployAngle = deployAngle
            -- set authority limiter directly in degrees instead of %
            data.AuthorityLimiter.storedValue = clamp(authorityAngle, 0.0, rangeAngle)
        end)
    end)
end

local function patchAirbrake(part)
    part:PatchModule("Module_ControlSurface", function(module)
        module:PatchData("Data_ControlSurface", function(data)
            data.CtrlSurfaceRange            = deployAngle   
            data.CtrlSurfaceDeployAngle      = deployAngle
            data.UseCtrlSurfaceDeployAngle   = true
        end)
    end)
end

--  procedural control surfaces 

PM.Parts:Patch("CtrlSurface_Procedural")
    :Named("controlsurface_*")
    :Requires(enabledmod, "mod is disabled.")
    :Do(function(part) patchSurface(part, ctrlSurfaceAuthorityAngle, deflectionRange) end)

--  grid frins

PM.Parts:Patch("CtrlSurface_GridFins")
    :Named("gridfin_1v_radial", "gridfin_2v_radial")
    :Requires(enabledmod, "mod is disabled.")
    :Do(function(part) patchSurface(part, gridFinAuthorityAngle, deployAngle) end)

--  airbrake 

PM.Parts:Patch("CtrlSurface_Airbrake")
    :Named("airbrake_1v")
    :Requires(enabledmod, "mod is disabled.")
    :Do(function(part) patchAirbrake(part) end)
    -- added mod is disabled check 
